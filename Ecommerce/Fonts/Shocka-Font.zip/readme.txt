Shocka is available for free trial for personal & commercial license

Shocka is available for commercial:
https://www.myfonts.com/foundry/skinny-type/

Appreciate this project to support me in making other amazing projects:
https://www.behance.net/skinny_type

Visit my Instagram:
https://www.instagram.com/skinny.type/
